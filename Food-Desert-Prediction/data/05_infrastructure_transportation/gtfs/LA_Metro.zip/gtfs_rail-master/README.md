# Los Angeles County Metropolitan Transportation Authority's GTFS for Rail.
## updated 2025-11-14 01:30:03 PST America/Los_Angeles

As of May 6th, 2016 The LACMTA is now publishing our Bus and Rail Services in separate Google Transit Exports ONLY. As a customer service, and to allow us to update these files more frequently, we have split these files up. The new rail-only export will be updated Daily (generally Tuesday-Saturday mornings), to allow us to send out more timely information and to allow our users to capture all temporary rail service changes that may occur on a daily basis. The bus-only exports will continue to be provided as large-scale changes to the system occur -- generally once every one or two months. We will NOT continue to maintain the combined service feeds.

### Join our developer community at [http://developer.metro.net](http://developer.metro.net) to learn more about using this data.

### Link to LACMTA's Bus Data repository: [https://gitlab.com/LACMTA/gtfs_bus/](https://gitlab.com/LACMTA/gtfs_bus/)

---

### Evergreen link to the gtfs_rail.zip archive: [https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip](https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip?1763112603.0597022)

### Today's link to the gtfs_rail.zip archive: [https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip?1763112603.0597022](https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip?1763112603.0597022)


### zip archive contents
```
 Length   Creation datetime         Name         
------------------------------------------------
     174  2025-11-14 00:12   agency.txt          
    1059  2025-11-14 00:12   calendar.txt        
     316  2025-11-14 00:12   calendar_dates.txt  
     120  2024-07-11 11:40   fare_attributes.txt 
      60  2024-07-11 11:44   fare_rules.txt      
     500  2025-11-14 00:12   routes.txt          
  727009  2025-08-27 13:58   shapes.txt          
   37281  2025-09-05 11:06   stops.txt           
10621620  2025-11-14 00:13   stop_times.txt      
  297476  2025-11-14 00:12   trips.txt           
     285  2025-11-14 00:32   feed_info.txt       
```

## Summary of changes
```
commit 60ba0977b1a16b87be3e7a577fc5aedbde26e71b
Author: activebatch <activebatch@MTAABEXEC01>
Date:   Thu Nov 13 01:30:08 2025 -0800

    2025-11-13 01:30:02 PST America/Los_Angeles

 README.md          |   38 +-
 calendar.txt       |   15 +-
 calendar_dates.txt |    4 +
 gtfs_rail.zip      |  Bin 1087843 -> 1055508 bytes
 stop_times.txt     | 4320 ----------------------------------------------------
 trips.txt          |  347 -----
 6 files changed, 30 insertions(+), 4694 deletions(-)
```

## Subscribing to changes

### Get the latest commit ID with Curl

```
#!/bin/sh

url="https://gitlab.com/LACMTA/gtfs_rail/commits/master.atom"

curl --silent "$url" | grep -E '(title>|updated>)' | \
  sed -n '4,$p' | \
  sed -e 's/<title>//' -e 's/<\/title>//' -e 's/<updated>/   /' \
      -e 's/<\/updated>//' | \
  head -2 | fmt

# returns:
# 2015-12-31T13:09:36Z
#    new info from SPA and instructions on preparing the archive
```

### Get the latest commit ID with Python

```
#!/bin/env python

import feedparser

url = 'https://gitlab.com/LACMTA/gtfs_rail/commits/master.atom'
d = feedparser.parse(url)
lastupdate = d['feed']['updated']

print(lastupdate)

```

See the [http://developer.metro.net/the-basics/policies/terms-and-conditions/](http://developer.metro.net/the-basics/policies/terms-and-conditions/) page for terms and conditions.
